#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE 1000
#define MAX_SATIR 1000

// K���k harfe �evirme fonksiyonu
void toLowerCase(char *str) {
    int i;
    for (i = 0; str[i]; i++) {
        str[i] = (char)tolower((unsigned char)str[i]);
    }
}

int main() {
    
    system("COLOR D");
    
    char dosyaAdi[100];
    char arananKelime[100];
    char satir[MAX_LINE];
    char geciciSatir[MAX_LINE];

    int satirNo = 1;
    int toplamTekrar = 0;
    int bulunanSatirlar[MAX_SATIR];
    int bulunanSatirSayisi = 0;
    int i;

    FILE *dosya, *raporDosyasi;

    printf("Dosya adini giriniz: ");
    if (fgets(dosyaAdi, sizeof(dosyaAdi), stdin) != NULL) {
        dosyaAdi[strcspn(dosyaAdi, "\n")] = 0;
    }

    dosya = fopen(dosyaAdi, "r");
    if (dosya == NULL) {
        printf("HATA: Dosya acilamadi! Dosyanin .c dosyasiyla ayni klasorde oldugundan emin olun.\n");
        return 1;
    }

    // Rapor dosyas�n� yazma modunda a��yoruz
    raporDosyasi = fopen("rapor.txt", "w");
    if (raporDosyasi == NULL) {
        printf("HATA: Rapor dosyasi olusturulamadi!\n");
        fclose(dosya);
        return 1;
    }

    printf("Aranacak kelimeyi giriniz: ");
    scanf("%s", arananKelime);

    toLowerCase(arananKelime);

    // Ana d�ng�: Dosyay� sat�r sat�r oku
    while (fgets(satir, MAX_LINE, dosya) != NULL) {
        strcpy(geciciSatir, satir);
        toLowerCase(geciciSatir);

        char *ptr = geciciSatir;
        int buSatirdaKacDefa = 0;

        // Kelimeyi sat�r i�inde ara
        while ((ptr = strstr(ptr, arananKelime)) != NULL) {
            toplamTekrar++;
            buSatirdaKacDefa++;
            ptr += strlen(arananKelime);
        }

        // E�er kelime bu sat�rda ge�tiyse hem terminale hem dosyaya yazd�r
        if (buSatirdaKacDefa > 0) {
            if (bulunanSatirSayisi < MAX_SATIR) {
                bulunanSatirlar[bulunanSatirSayisi++] = satirNo;
            }
            printf("%d. satirda '%s' kelimesi %d kez gecti.\n", satirNo, arananKelime, buSatirdaKacDefa);
            fprintf(raporDosyasi, "%d. satirda '%s' kelimesi %d kez gecti.\n", satirNo, arananKelime, buSatirdaKacDefa);
        }

        satirNo++;
    }

    // -------- RAPOR B�L�M� --------
    // Terminale yazd�rma b�l�m�
    printf("\n========== RAPOR ==========\n");
    printf("Aranan kelime: %s\n", arananKelime);
    printf("Toplam tekrar sayisi: %d\n", toplamTekrar);
    printf("Gectigi farkli satir sayisi: %d\n", bulunanSatirSayisi);
    printf("Gectigi satir numaralari: ");

    // Dosyaya yazd�rma b�l�m�
    fprintf(raporDosyasi, "\n========== RAPOR ==========\n");
    fprintf(raporDosyasi, "Aranan kelime: %s\n", arananKelime);
    fprintf(raporDosyasi, "Toplam tekrar sayisi: %d\n", toplamTekrar);
    fprintf(raporDosyasi, "Gectigi farkli satir sayisi: %d\n", bulunanSatirSayisi);
    fprintf(raporDosyasi, "Gectigi satir numaralari: ");

    for (i = 0; i < bulunanSatirSayisi; i++) {
        printf("%d ", bulunanSatirlar[i]);
        fprintf(raporDosyasi, "%d ", bulunanSatirlar[i]);
    }

    printf("\n===========================\n");
    fprintf(raporDosyasi, "\n===========================\n");

    printf("\nRapor basariyla 'rapor.txt' dosyasina kaydedildi.\n");

    fclose(dosya);
    fclose(raporDosyasi);

    return 0;
}
